/* macgui7.c - Apple Macintosh 128K facsimile (System 1.0 look), OpenHarmony QEMU guest.
 * Tribute: Apple 50th anniversary (1976-2026).
 * Authentic internal screen 512x342 (Mac 128K), scaled x2 -> 1024x684 on framebuffer.
 * Runs as /init in a tiny initrd. Input: /dev/input/event* (virtio-mouse / -keyboard).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <linux/input.h>
#include <linux/fb.h>
#include "font8x10.h"

#define NEV 8
#define MACW 512
#define MACH 342
#define SCALE 2
#define MBAR 20
#define TITLEBAR 18
#define SB 16
#define DOCKH 22
#define PCW 260
#define PCH 140

#define C_BLACK 0x000000u
#define C_WHITE 0xFFFFFFu
#define C_GRAY  0x808080u
#define C_LGRAY 0xAAAAAAu
#define C_DKGRAY 0x555555u
#define C_RAIN_R 0xDD2C00u
#define C_RAIN_O 0xFF6D00u
#define C_RAIN_Y 0xFFD600u
#define C_RAIN_G 0x64DD17u
#define C_RAIN_B 0x0091EAu
#define C_RAIN_V 0xAA00FFu

static int fb_fd = -1;
static unsigned char *fb = NULL;
static int fb_w = 0, fb_h = 0, fb_bpp = 0, fb_stride = 0;
static int have_fb = 0;
static unsigned char *scene = NULL, *front = NULL, *dst = NULL;
static int mstride = MACW * 4;
static int offx = 0, offy = 42;
static int ifd[NEV];
static int px = 256, py = 200;
static int scene_dirty = 1;
static void set_dst(unsigned char *p) { dst = p; }

static void put_px(int x, int y, unsigned int c) {
  if (!dst) return;
  if (x < 0 || y < 0 || x >= MACW || y >= MACH) return;
  unsigned char *p = dst + (size_t)y * mstride + (size_t)x * 4;
  p[0] = c & 0xff; p[1] = (c >> 8) & 0xff; p[2] = (c >> 16) & 0xff; p[3] = 0xff;
}
static void rect(int x, int y, int w, int h, unsigned int c) {
  int x1 = x + w, y1 = y + h;
  if (x < 0) x = 0;
  if (y < 0) y = 0;
  if (x1 > MACW) x1 = MACW;
  if (y1 > MACH) y1 = MACH;
  for (int j = y; j < y1; j++) { unsigned char *r = dst ? dst + (size_t)j * mstride : NULL; if (!r) return;
    for (int i = x; i < x1; i++) { unsigned char *p = r + (size_t)i * 4; p[0] = c & 0xff; p[1] = (c >> 8) & 0xff; p[2] = (c >> 16) & 0xff; p[3] = 0xff; } }
}
static void frame(int x, int y, int w, int h, unsigned int c) {
  rect(x, y, w, 1, c); rect(x, y + h - 1, w, 1, c); rect(x, y, 1, h, c); rect(x + w - 1, y, 1, h, c);
}
static void dither(int x, int y, int w, int h, unsigned int c1, unsigned int c2) {
  int x1 = x + w, y1 = y + h;
  if (x < 0) x = 0;
  if (y < 0) y = 0;
  if (x1 > MACW) x1 = MACW;
  if (y1 > MACH) y1 = MACH;
  for (int j = y; j < y1; j++) for (int i = x; i < x1; i++) put_px(i, j, ((i ^ j) & 1) ? c1 : c2);
}
static int text_w(const char *s) { int w = 0; for (; *s; s++) { unsigned char c = (unsigned char)*s; if (c < 32 || c > 126) c = 32; w += FONT8_W[c - FONT_FIRST] + 1; } return w; }
static void text(int x, int y, const char *s, unsigned int fg) {
  for (; *s; s++) {
    unsigned char c = (unsigned char)*s; if (c < 32 || c > 126) c = 32;
    const unsigned char *g = FONT8[c - FONT_FIRST]; int gw = FONT8_W[c - FONT_FIRST];
    for (int r = 0; r < FONT_H; r++) { unsigned char b = g[r];
      for (int i = 0; i < gw; i++) if (b & (1 << i)) put_px(x + i, y + r, fg); }
    x += gw + 1;
  }
}
static void text_bg(int x, int y, const char *s, unsigned int fg, unsigned int bg) {
  int w = text_w(s);
  rect(x - 1, y - 1, w + 2, FONT_H + 2, bg);
  text(x, y, s, fg);
}
static void invert_rect(int x, int y, int w, int h) {
  if (!dst) return;
  int x1 = x + w, y1 = y + h;
  if (x < 0) x = 0;
  if (y < 0) y = 0;
  if (x1 > MACW) x1 = MACW;
  if (y1 > MACH) y1 = MACH;
  for (int j = y; j < y1; j++) for (int i = x; i < x1; i++) { unsigned char *p = dst + (size_t)j * mstride + (size_t)i * 4; p[0] = ~p[0]; p[1] = ~p[1]; p[2] = ~p[2]; }
}
static void triangles_up(int x, int y, int s) { for (int r = 0; r < s; r++) rect(x + s - 1 - r, y + r, 1 + 2 * r, 1, C_BLACK); }
static void triangles_down(int x, int y, int s) { for (int r = 0; r < s; r++) rect(x + r, y + r, s * 2 - 1 - 2 * r, 1, C_BLACK); }
static void triangles_left(int x, int y, int s) { for (int r = 0; r < s; r++) rect(x + r, y + r, 1, s * 2 - 1 - 2 * r, C_BLACK); }
static void triangles_right(int x, int y, int s) { for (int r = 0; r < s; r++) rect(x + s - 1 - r, y + r, 1, s * 2 - 1 - 2 * r, C_BLACK); }
static long now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000L + ts.tv_nsec / 1000000L; }
static void clk_str(char *o, int withsec) {
  time_t t = time(NULL); struct tm *tmv = localtime(&t);
  int h = tmv ? tmv->tm_hour : 0, m = tmv ? tmv->tm_min : 0, s = tmv ? tmv->tm_sec : 0;
  if (withsec) snprintf(o, 16, "%02d:%02d:%02d", h, m, s); else snprintf(o, 16, "%02d:%02d", h, m);
}

/* ---- x2 scaler to the real framebuffer ---- */
static void paint_letterbox(void) {
  for (int j = 0; j < fb_h; j++) {
    unsigned char *r = fb + (size_t)j * fb_stride;
    if (j >= offy && j < offy + MACH * SCALE) continue;
    for (int i = 0; i < fb_w; i++) { unsigned char *p = r + (size_t)i * 4; p[0] = 0; p[1] = 0; p[2] = 0; p[3] = 255; }
  }
}
static void blit_rect(int mx, int my, int mw, int mh) {
  if (!have_fb || !front) return;
  int x1 = mx + mw, y1 = my + mh;
  if (mx < 0) mx = 0;
  if (my < 0) my = 0;
  if (x1 > MACW) x1 = MACW;
  if (y1 > MACH) y1 = MACH;
  if (mx >= x1 || my >= y1) return;
  for (int j = my; j < y1; j++) {
    unsigned char *s = front + (size_t)j * mstride + (size_t)mx * 4;
    unsigned char *d1 = fb + (size_t)(offy + j * SCALE) * fb_stride + (size_t)(offx + mx * SCALE) * 4;
    unsigned char *d2 = d1 + fb_stride;
    for (int i = 0; i < (x1 - mx); i++) {
      d1[0] = s[0]; d1[1] = s[1]; d1[2] = s[2]; d1[3] = 255;
      d1[4] = s[0]; d1[5] = s[1]; d1[6] = s[2]; d1[7] = 255;
      d2[0] = s[0]; d2[1] = s[1]; d2[2] = s[2]; d2[3] = 255;
      d2[4] = s[0]; d2[5] = s[1]; d2[6] = s[2]; d2[7] = 255;
      s += 4; d1 += 8; d2 += 8;
    }
  }
}
static void restore_rect(int x, int y, int w, int h) {
  if (!front || !scene) return;
  int x1 = x + w, y1 = y + h;
  if (x < 0) x = 0;
  if (y < 0) y = 0;
  if (x1 > MACW) x1 = MACW;
  if (y1 > MACH) y1 = MACH;
  for (int j = y; j < y1; j++)
    memcpy(front + (size_t)j * mstride + (size_t)x * 4, scene + (size_t)j * mstride + (size_t)x * 4, (size_t)(x1 - x) * 4);
}


/* ================= Macintosh chrome ================= */
#define MAXW 6
typedef struct { int used, x, y, w, h, z, kind; char title[40]; char body[14][64]; int lines, caret; int tool, pat; unsigned char canvas[PCW*PCH]; } Win;
static Win wins[MAXW];
static int zseq = 0;
static Win *drag_w = NULL; static int drag_dx = 0, drag_dy = 0;
static int sel_icon = -1;
static int blink = 0;
static int dlg = 0;                 /* 0 none, 1 about, 2 alert */
static char dlg_msg[128];

static Win *top_win(void) { Win *t = NULL; for (int i = 0; i < MAXW; i++) if (wins[i].used && (!t || wins[i].z > t->z)) t = &wins[i]; return t; }
static Win *hit_window(int x, int y) { Win *t = NULL; for (int i = 0; i < MAXW; i++) if (wins[i].used && x >= wins[i].x && x < wins[i].x + wins[i].w && y >= wins[i].y && y < wins[i].y + wins[i].h) { if (!t || wins[i].z > t->z) t = &wins[i]; } return t; }
static void close_win(Win *w) { if (w) { w->used = 0; if (drag_w == w) drag_w = NULL; } }

/* ================= MacPaint ================= */
static void open_win(int kind);
static void focus_front(Win *w);
static unsigned char pat_bit(int pat, int x, int y) {
  switch (pat) {
    case 0: return 0;
    case 1: return ((x & 1) || (y & 1)) ? 0 : 1;
    case 2: return (unsigned char)((x + y) & 1);
    case 3: return ((x & 1) && (y & 1)) ? 0 : 1;
    case 4: return 1;
    case 5: return (unsigned char)(((x >> 1) + (y >> 1)) & 1);
    case 6: return (unsigned char)((x % 3 == 0) && (y % 3 == 0));
    case 7: return (unsigned char)(y & 1);
  }
  return 0;
}
static void mp_geom(Win *w, int *cx, int *cy) { *cx = w->x + 22; *cy = w->y + TITLEBAR + 2; }
static void mp_put(Win *w, int mx, int my, int val) {
  int cx, cy; mp_geom(w, &cx, &cy);
  int lx = mx - cx, ly = my - cy;
  if (lx < 0 || ly < 0 || lx >= PCW || ly >= PCH) return;
  w->canvas[ly * PCW + lx] = (unsigned char)val;
}
static void mp_line(Win *w, int x0, int y0, int x1, int y1, int val, int thick) {
  int dx = x1 - x0, dy = y1 - y0; if (dx < 0) dx = -dx; if (dy < 0) dy = -dy;
  int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx - dy;
  for (;;) {
    if (thick) { for (int j = -3; j <= 3; j++) for (int i = -3; i <= 3; i++) mp_put(w, x0 + i, y0 + j, val); }
    else mp_put(w, x0, y0, val);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * err;
    if (e2 > -dy) { err -= dy; x0 += sx; }
    if (e2 < dx) { err += dx; y0 += sy; }
  }
}
static void mp_rectw(Win *w, int x0, int y0, int x1, int y1, int val) {
  if (x0 > x1) { int t = x0; x0 = x1; x1 = t; }
  if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
  for (int i = x0; i <= x1; i++) { mp_put(w, i, y0, val); mp_put(w, i, y1, val); }
  for (int j = y0; j <= y1; j++) { mp_put(w, x0, j, val); mp_put(w, x1, j, val); }
}
static void draw_macpaint(Win *w) {
  int cx, cy; mp_geom(w, &cx, &cy);
  rect(cx - 1, cy - 1, PCW + 2, PCH + 2, C_BLACK);
  rect(cx, cy, PCW, PCH, C_WHITE);
  for (int y = 0; y < PCH; y++) for (int x = 0; x < PCW; x++) if (w->canvas[y * PCW + x]) put_px(cx + x, cy + y, C_BLACK);
  int tx = w->x + 2, ty = w->y + TITLEBAR + 2;
  for (int i = 0; i < 5; i++) {
    int r = ty + i * 18;
    rect(tx, r, 18, 18, (i == w->tool) ? C_BLACK : C_WHITE); frame(tx, r, 18, 18, C_BLACK);
    unsigned int fg = (i == w->tool) ? C_WHITE : C_BLACK;
    if (i == 0) { for (int k = 0; k < 10; k++) put_px(tx + 4 + k, r + 4 + k, fg); }
    else if (i == 1) { rect(tx + 5, r + 5, 8, 8, fg); }
    else if (i == 2) { for (int k = 0; k < 12; k++) put_px(tx + 3 + k, r + 14 - k, fg); }
    else if (i == 3) { frame(tx + 4, r + 5, 10, 9, fg); }
    else { for (int k = 0; k < 14; k++) put_px(tx + 3 + ((k * 7) % 12), r + 3 + ((k * 5) % 12), fg); }
  }
  int px0 = w->x + 22, py0 = w->y + TITLEBAR + 2 + PCH + 4;
  for (int i = 0; i < 8; i++) {
    int c = px0 + i * 20;
    rect(c, py0, 18, 18, C_WHITE); frame(c, py0, 18, 18, C_BLACK);
    for (int yy = 1; yy < 17; yy++) for (int xx = 1; xx < 17; xx++) if (pat_bit(i, xx, yy)) put_px(c + xx, py0 + yy, C_BLACK);
    if (i == w->pat) frame(c - 1, py0 - 1, 20, 20, C_BLACK);
  }
  text(w->x + 24, py0 + 22, "MacPaint", C_BLACK);
}
static int mp_hit(Win *w, int x, int y) {
  int cx, cy; mp_geom(w, &cx, &cy);
  if (x >= cx && x < cx + PCW && y >= cy && y < cy + PCH) return 1;
  int tx = w->x + 2, ty = w->y + TITLEBAR + 2;
  for (int i = 0; i < 5; i++) if (x >= tx && x < tx + 18 && y >= ty + i * 18 && y < ty + i * 18 + 18) return 10 + i;
  int px0 = w->x + 22, py0 = w->y + TITLEBAR + 2 + PCH + 4;
  for (int i = 0; i < 8; i++) if (x >= px0 + i * 20 && x < px0 + i * 20 + 18 && y >= py0 && y < py0 + 18) return 20 + i;
  return 0;
}
static Win *paint_w = NULL;
static int painting = 0, paint_x0 = 0, paint_y0 = 0, paint_x1 = 0, paint_y1 = 0;
static void mp_press(Win *w, int x, int y) {
  int h = mp_hit(w, x, y);
  if (h >= 10 && h < 15) { w->tool = h - 10; return; }
  if (h >= 20) { w->pat = h - 20; return; }
  if (h == 1) {
    paint_w = w; painting = 1; paint_x0 = paint_x1 = x; paint_y0 = paint_y1 = y;
    if (w->tool == 0) mp_line(w, x, y, x, y, w->pat, 0);
    else if (w->tool == 1) mp_line(w, x, y, x, y, 0, 1);
    else if (w->tool == 4) { for (int k = 0; k < 40; k++) mp_put(w, x + ((k * 13) % 15) - 7, y + ((k * 7) % 15) - 7, w->pat); }
  }
}
static void mp_drag(void) {
  if (!painting || !paint_w) return;
  Win *w = paint_w;
  if (w->tool == 0) mp_line(w, paint_x1, paint_y1, px, py, w->pat, 0);
  else if (w->tool == 1) mp_line(w, paint_x1, paint_y1, px, py, 0, 1);
  else if (w->tool == 4) { for (int k = 0; k < 20; k++) mp_put(w, px + ((k * 11) % 11) - 5, py + ((k * 7) % 11) - 5, w->pat); }
  paint_x1 = px; paint_y1 = py;
}
static void mp_release(void) {
  if (!painting || !paint_w) { painting = 0; return; }
  Win *w = paint_w;
  if (w->tool == 2) mp_line(w, paint_x0, paint_y0, px, py, w->pat, 0);
  else if (w->tool == 3) mp_rectw(w, paint_x0, paint_y0, px, py, w->pat);
  painting = 0; paint_w = NULL; scene_dirty = 1;
}
static void mp_clear(Win *w) { if (w && w->kind == 3) { memset(w->canvas, 0, sizeof w->canvas); scene_dirty = 1; } }

/* ================= Dock ================= */
#define NDOCK 5
static void dock_geom(int i, int *x, int *y) { *x = 8 + i * 30; *y = MACH - DOCKH + 2; }
static int dock_hit(int x, int y) {
  if (y < MACH - DOCKH) return -1;
  for (int i = 0; i < NDOCK; i++) { int dx, dy; dock_geom(i, &dx, &dy); if (x >= dx - 1 && x < dx + 19 && y >= dy - 1 && y < dy + 19) return i; }
  return -1;
}
static void draw_dock(void) {
  rect(0, MACH - DOCKH, MACW, 1, C_BLACK);
  rect(0, MACH - DOCKH + 1, MACW, DOCKH - 1, C_WHITE);
  for (int i = 0; i < NDOCK; i++) {
    int dx, dy; dock_geom(i, &dx, &dy);
    rect(dx, dy, 18, 18, C_WHITE); frame(dx, dy, 18, 18, C_BLACK);
    if (i == 0) { frame(dx + 3, dy + 3, 12, 12, C_BLACK); rect(dx + 6, dy + 6, 6, 3, C_BLACK); }
    else if (i == 1) { rect(dx + 4, dy + 2, 10, 14, C_WHITE); frame(dx + 4, dy + 2, 10, 14, C_BLACK); rect(dx + 6, dy + 5, 6, 1, C_BLACK); rect(dx + 6, dy + 8, 6, 1, C_BLACK); }
    else if (i == 2) { for (int k = 0; k < 9; k++) put_px(dx + 4 + k, dy + 12 - k, C_BLACK); rect(dx + 10, dy + 3, 5, 5, C_BLACK); }
    else if (i == 3) { rect(dx + 5, dy + 5, 8, 10, C_WHITE); frame(dx + 5, dy + 5, 8, 10, C_BLACK); rect(dx + 4, dy + 3, 10, 2, C_BLACK); }
    else { rect(dx + 3, dy + 3, 5, 5, C_BLACK); rect(dx + 10, dy + 3, 5, 5, C_BLACK); rect(dx + 3, dy + 10, 5, 5, C_BLACK); rect(dx + 10, dy + 10, 5, 5, C_BLACK); }
  }
}
static void tile_windows(void) {
  int n = 0; for (int i = 0; i < MAXW; i++) if (wins[i].used) n++;
  if (n == 0) return;
  int cols = (n <= 2) ? n : 2, rows = (n + cols - 1) / cols;
  int gw = (MACW - 12) / cols, gh = (MACH - MBAR - DOCKH - 12) / rows;
  int k = 0;
  for (int i = 0; i < MAXW; i++) if (wins[i].used) {
    int r = k / cols, c = k % cols;
    wins[i].x = 6 + c * gw; wins[i].y = MBAR + 4 + r * gh;
    wins[i].w = gw - 6; wins[i].h = gh - 6;
    if (wins[i].w < 140) wins[i].w = 140;
    if (wins[i].h < 100) wins[i].h = 100;
    wins[i].z = ++zseq;
    k++;
  }
  printf("MACGUI7: tiled %d windows\n", n);
  scene_dirty = 1;
}
static void dock_action(int i) {
  Win *w = NULL;
  int kinds[4] = { 1, 0, 3, 2 };
  if (i < 4) {
    for (int k = 0; k < MAXW; k++) if (wins[k].used && wins[k].kind == kinds[i]) w = &wins[k];
    if (w) focus_front(w); else open_win(kinds[i]);
  } else tile_windows();
  scene_dirty = 1;
}


/* ---- desktop icons ---- */
#define NICO 2
typedef struct { int x, y; const char *label; int kind; } Icon;   /* kind 1 = disk, 2 = trash */
static Icon icons[NICO];

static void draw_floppy(int x, int y) {
  rect(x, y, 32, 32, C_WHITE); frame(x, y, 32, 32, C_BLACK);
  rect(x + 9, y, 16, 11, C_WHITE); frame(x + 9, y, 16, 11, C_BLACK);
  rect(x + 12, y + 3, 10, 5, C_WHITE); rect(x + 12, y + 3, 3, 5, C_BLACK);
  rect(x + 5, y + 19, 22, 10, C_WHITE); frame(x + 5, y + 19, 22, 10, C_BLACK);
  for (int i = 0; i < 3; i++) rect(x + 8, y + 21 + i * 3, 16, 1, C_BLACK);
}
static void draw_trash(int x, int y) {
  rect(x + 6, y + 6, 20, 26, C_WHITE); frame(x + 6, y + 6, 20, 26, C_BLACK);
  rect(x + 4, y + 2, 24, 4, C_WHITE); frame(x + 4, y + 2, 24, 4, C_BLACK);
  rect(x + 12, y, 8, 3, C_WHITE); frame(x + 12, y, 8, 3, C_BLACK);
  for (int i = 0; i < 3; i++) rect(x + 10 + i * 6, y + 10, 1, 18, C_BLACK);
}
static void draw_icon(Icon *ic, int sel) {
  if (sel) invert_rect(ic->x - 3, ic->y - 3, 38, 54);
  if (ic->kind == 1) draw_floppy(ic->x, ic->y); else draw_trash(ic->x, ic->y);
  int tw = text_w(ic->label);
  text(ic->x + 16 - tw / 2, ic->y + 36, ic->label, C_BLACK);
}
static void init_icons(void) {
  icons[0].x = MACW - 76; icons[0].y = 30;  icons[0].kind = 1; icons[0].label = "Macintosh HD";   /* top-right, as on the 128K */
  icons[1].x = MACW - 76; icons[1].y = MACH - 118; icons[1].kind = 2; icons[1].label = "Trash";  /* bottom-right */
}
static int hit_icon(int x, int y) {
  for (int i = 0; i < NICO; i++) if (x >= icons[i].x - 3 && x < icons[i].x + 35 && y >= icons[i].y - 3 && y < icons[i].y + 52) return i;
  return -1;
}

/* ---- strict System 1.0 window chrome ---- */
static void draw_window(Win *w) {
  int active = (top_win() == w);
  /* drop shadow (System 1.0 had none, but 2px offset reads well; keep subtle) */
  rect(w->x, w->y, w->w, w->h, C_WHITE);
  frame(w->x, w->y, w->w, w->h, C_BLACK);
  /* striped title bar */
  for (int r = 1; r < TITLEBAR - 1; r++) if (r & 1) rect(w->x + 1, w->y + r, w->w - 2, 1, C_BLACK);
  /* close box */
  rect(w->x + 2, w->y + 2, 12, 12, C_WHITE); frame(w->x + 2, w->y + 2, 12, 12, C_BLACK);
  if (active) { rect(w->x + 5, w->y + 5, 6, 6, C_WHITE); frame(w->x + 5, w->y + 5, 6, 6, C_BLACK); }
  /* title on a clear strip */
  {
    int tw = text_w(w->title);
    int tx = w->x + (w->w - tw) / 2;
    rect(w->x + 16, w->y + 3, w->w - 32, FONT_H + 1, C_WHITE);
    text(tx, w->y + 4, w->title, C_BLACK);
  }
  /* body */
  int bx = w->x + 1, by = w->y + TITLEBAR, bw = w->w - 2 - SB, bh = w->h - TITLEBAR - 1 - SB;
  rect(bx, by, bw, bh, C_WHITE);
  if (w->kind == 0) {
    for (int i = 0; i < w->lines; i++) text(bx + 6, by + 8 + i * (FONT_H + 2), w->body[i], C_BLACK);
  } else if (w->kind == 1) {
    const char *items[4] = { "System Folder", "Applications", "Documents", "Trash" };
    for (int i = 0; i < 4; i++) { rect(bx + 10, by + 8 + i * 20, 12, 12, C_WHITE); frame(bx + 10, by + 8 + i * 20, 12, 12, C_BLACK); text(bx + 28, by + 9 + i * 20, items[i], C_BLACK); }
    text(bx + 8, by + bh - 16, "4 items", C_BLACK);
  } else if (w->kind == 2) {
    text(bx + 10, by + 12, "Trash is empty.", C_BLACK);
  } else if (w->kind == 3) {
    draw_macpaint(w);
  }
  /* right scrollbar */
  {
    int sx = w->x + w->w - 1 - SB, sy = w->y + TITLEBAR, sh = w->h - TITLEBAR - SB - 1;
    rect(sx, sy, SB, sh, C_WHITE); frame(sx, sy, SB, sh, C_BLACK);
    dither(sx + 1, sy + SB, SB - 2, sh - 2 * SB - 2, C_LGRAY, C_WHITE);
    rect(sx, sy, SB, SB, C_WHITE); frame(sx, sy, SB, SB, C_BLACK); triangles_up(sx + 6, sy + 5, 4);
    rect(sx, sy + sh - SB, SB, SB, C_WHITE); frame(sx, sy + sh - SB, SB, SB, C_BLACK); triangles_down(sx + 6, sy + sh - SB + 3, 4);
  }
  /* bottom scrollbar */
  {
    int sx = w->x + 1, sy = w->y + w->h - 1 - SB, sw = w->w - 1 - SB;
    rect(sx, sy, sw, SB, C_WHITE); frame(sx, sy, sw, SB, C_BLACK);
    dither(sx + SB, sy + 1, sw - 2 * SB - 2, SB - 2, C_LGRAY, C_WHITE);
    rect(sx, sy, SB, SB, C_WHITE); frame(sx, sy, SB, SB, C_BLACK); triangles_left(sx + 5, sy + 6, 4);
    rect(sx + sw - SB, sy, SB, SB, C_WHITE); frame(sx + sw - SB, sy, SB, SB, C_BLACK); triangles_right(sx + sw - SB + 3, sy + 6, 4);
  }
  /* size box */
  {
    int bx2 = w->x + w->w - 1 - SB, by2 = w->y + w->h - 1 - SB;
    rect(bx2, by2, SB, SB, C_WHITE);
    rect(bx2, by2, SB, 1, C_BLACK); rect(bx2, by2, 1, SB, C_BLACK);
    for (int i = 0; i < 3; i++) { int ox = bx2 + 4 + i * 4; for (int k = 0; k < 9; k++) put_px(ox + k, by2 + SB - 2 - k, C_BLACK); }
  }
}

/* ---- menu bar with rainbow Apple logo ---- */
static const char *APPLE_MASK[18] = {
  "......###.......",
  ".....#####......",
  "......###.......",
  "....#######.....",
  "..###########...",
  ".#############..",
  "###############.",
  "############....",
  "###########.....",
  "##########......",
  "##########......",
  "###########.....",
  "############....",
  ".#############..",
  "..###########...",
  "...#########....",
  ".....#####......",
  "......###......."
};
static unsigned int rainbow_row(int r) {
  if (r < 3) return C_RAIN_G;
  if (r < 6) return C_RAIN_Y;
  if (r < 8) return C_RAIN_O;
  if (r < 10) return C_RAIN_R;
  if (r < 13) return C_RAIN_V;
  return C_RAIN_B;
}
static void draw_apple_logo(int x, int y) {
  for (int r = 0; r < 18; r++) for (int c = 0; c < 16; c++) if (APPLE_MASK[r][c] == '#') put_px(x + c, y + r, rainbow_row(r));
}


/* ================= menus ================= */
#define ITEM_H 17
static const char *M_AP[] = { "About This Macintosh...", "-", "Control Panel", "Chooser", "Scrapbook", "Alarm Clock" };
static const char *M_FI[] = { "New", "Open...", "-", "Close", "Save", "Save As...", "-", "Quit" };
static const char *M_ED[] = { "Undo", "-", "Cut", "Copy", "Paste", "Clear" };
static const char *M_VI[] = { "by Icon", "by Name", "by Size", "by Date" };
static const char *M_SP[] = { "Clean Up Window", "Empty Trash", "-", "Shut Down..." };
typedef struct { const char *title; const char **items; int n, x, tw; } MenuDef;
static MenuDef menus[5];
static int menu_open = -1, menu_sel = -1, menu_hover_x = 0;
static void init_menus(void) {
  menus[0].title = ""; menus[0].items = M_AP; menus[0].n = 6; menus[0].x = 4; menus[0].tw = 24;
  menus[1].title = "File";    menus[1].items = M_FI; menus[1].n = 8;
  menus[2].title = "Edit";    menus[2].items = M_ED; menus[2].n = 6;
  menus[3].title = "View";    menus[3].items = M_VI; menus[3].n = 4;
  menus[4].title = "Special"; menus[4].items = M_SP; menus[4].n = 4;
  int x = 34;
  for (int i = 1; i < 5; i++) { menus[i].x = x; menus[i].tw = text_w(menus[i].title); x += menus[i].tw + 18; }
}
static int menu_index_at(int x, int y) {
  if (y >= MBAR) return -1;
  if (x >= 2 && x < 30) return 0;
  for (int i = 1; i < 5; i++) if (x >= menus[i].x - 6 && x < menus[i].x + menus[i].tw + 6) return i;
  return -1;
}
static int dd_w(int mi) { int w = 0; for (int i = 0; i < menus[mi].n; i++) { int t = text_w(menus[mi].items[i]); if (t > w) w = t; } return w + 30; }
static void dd_geom(int mi, int *ox, int *oy, int *ow, int *oh) {
  *ow = dd_w(mi); *oh = menus[mi].n * ITEM_H + 6;
  *ox = (mi == 0) ? 2 : menus[mi].x - 6;
  if (*ox + *ow > MACW - 1) *ox = MACW - 1 - *ow;
  *oy = MBAR;
}
static int dd_item_at(int mi, int x, int y) {
  int ox, oy, ow, oh; dd_geom(mi, &ox, &oy, &ow, &oh);
  if (x < ox || x >= ox + ow || y < oy || y >= oy + oh) return -1;
  int i = (y - oy - 3) / ITEM_H;
  if (i < 0 || i >= menus[mi].n) return -1;
  if (strcmp(menus[mi].items[i], "-") == 0) return -1;
  return i;
}
static void draw_menu_bar(void) {
  rect(0, 0, MACW, MBAR, C_WHITE);
  rect(0, MBAR - 1, MACW, 1, C_BLACK);
  draw_apple_logo(6, 1);
  for (int i = 1; i < 5; i++) text(menus[i].x, 4, menus[i].title, C_BLACK);
  if (menu_open >= 0 && menu_open < 5) { invert_rect(menus[menu_open].x - 5, 2, menus[menu_open].tw + 10, MBAR - 4); if (menu_open >= 1) text(menus[menu_open].x, 4, menus[menu_open].title, C_WHITE); }
  char clk[16]; clk_str(clk, 1);
  text(MACW - 8 - text_w(clk), 4, clk, C_BLACK);
}
static void draw_dropdown(void) {
  int mi = menu_open; if (mi < 0) return;
  int ox, oy, ow, oh; dd_geom(mi, &ox, &oy, &ow, &oh);
  rect(ox, oy, ow, oh, C_WHITE); frame(ox, oy, ow, oh, C_BLACK);
  for (int i = 0; i < menus[mi].n; i++) {
    int iy = oy + 3 + i * ITEM_H;
    if (strcmp(menus[mi].items[i], "-") == 0) { rect(ox + 6, iy + ITEM_H / 2, ow - 12, 1, C_BLACK); continue; }
    if (i == menu_sel) invert_rect(ox + 2, iy, ow - 4, ITEM_H);
    text(ox + 14, iy + 3, menus[mi].items[i], i == menu_sel ? C_WHITE : C_BLACK);
  }
}

/* ================= dialogs ================= */
static void rounded_frame(int x, int y, int w, int h, unsigned int c) {
  frame(x, y, w, h, c);
  put_px(x, y, C_WHITE); put_px(x + w - 1, y, C_WHITE);
  put_px(x, y + h - 1, C_WHITE); put_px(x + w - 1, y + h - 1, C_WHITE);
}
static void draw_button(int x, int y, int w, int h, const char *label) {
  rect(x, y, w, h, C_WHITE);
  rounded_frame(x, y, w, h, C_BLACK); rounded_frame(x + 1, y + 1, w - 2, h - 2, C_BLACK); rounded_frame(x + 2, y + 2, w - 4, h - 4, C_BLACK);
  int tw = text_w(label);
  text(x + (w - tw) / 2, y + (h - FONT_H) / 2, label, C_BLACK);
}
static void draw_dialog(void) {
  if (!dlg) return;
  int w = 380, h = (dlg == 1) ? 196 : 130;
  int x = (MACW - w) / 2, y = (MACH - h) / 2;
  rect(x, y, w, h, C_WHITE);
  rounded_frame(x, y, w, h, C_BLACK); rounded_frame(x + 1, y + 1, w - 2, h - 2, C_BLACK);
  if (dlg == 1) {
    for (int r = 0; r < 18; r++) for (int c = 0; c < 16; c++) if (APPLE_MASK[r][c] == '#') {
      put_px(x + 24 + c * 2, y + 22 + r * 2, rainbow_row(r)); put_px(x + 25 + c * 2, y + 22 + r * 2, rainbow_row(r));
      put_px(x + 24 + c * 2, y + 23 + r * 2, rainbow_row(r)); put_px(x + 25 + c * 2, y + 23 + r * 2, rainbow_row(r));
    }
    text(x + 72, y + 24, "Macintosh 128K", C_BLACK);
    text(x + 72, y + 40, "512K RAM   400K Disk Drive", C_BLACK);
    rect(x + 20, y + 74, w - 40, 1, C_BLACK);
    text(x + 24, y + 86, "System 1.0 facsimile (1984)", C_BLACK);
    text(x + 24, y + 104, "OpenHarmony + QEMU virtual hardware", C_BLACK);
    rect(x + 20, y + 126, w - 40, 1, C_BLACK);
    text(x + 24, y + 138, "Tribute to Apple's 50th Anniversary", C_BLACK);
    text(x + 24, y + 154, "1976 - 2026", C_BLACK);
    draw_button(x + w / 2 - 34, y + h - 34, 68, 24, "OK");
  } else {
    text(x + 22, y + 26, dlg_msg, C_BLACK);
    draw_button(x + w / 2 - 34, y + h - 40, 68, 24, "OK");
  }
}

/* ================= scene ================= */
static void draw_pointer(int x, int y) {
  static const char *A[16] = {
    "#..........","##.........","#*#........","#**#.......","#***#......",
    "#****#.....","#*****#....","#******#...","#*******#..","#********#.",
    "#****#####.","#**#*#.....","#*#..#.....","##....#....","#......#...","........#.." };
  for (int r = 0; r < 16; r++) for (int c = 0; c < 11; c++) {
    char ch = A[r][c];
    if (ch == '#') put_px(x + c, y + r, C_BLACK);
    else if (ch == '*') put_px(x + c, y + r, C_WHITE);
  }
}
static void redraw_scene(void) {
  dither(0, MBAR, MACW, MACH - MBAR, C_GRAY, C_WHITE);
  for (int i = 0; i < NICO; i++) draw_icon(&icons[i], sel_icon == i);
  for (int z = 1; z <= zseq; z++) for (int i = 0; i < MAXW; i++) if (wins[i].used && wins[i].z == z) draw_window(&wins[i]);
  draw_dock();
  draw_menu_bar();
  if (menu_open >= 0) draw_dropdown();
  if (dlg) draw_dialog();
}


/* ================= actions ================= */
static long last_input_ms = 0;
static void open_win(int kind) {
  int slot = -1;
  for (int i = 0; i < MAXW; i++) if (!wins[i].used) { slot = i; break; }
  if (slot < 0) { close_win(top_win()); for (int i = 0; i < MAXW; i++) if (!wins[i].used) { slot = i; break; } }
  if (slot < 0) return;
  Win *w = &wins[slot]; memset(w, 0, sizeof *w);
  w->used = 1; w->kind = kind; w->w = 300; w->h = 190; w->x = 140; w->y = 60;
  if (kind == 3) { w->w = 300; w->h = 214; w->x = 26; w->y = 40; w->tool = 0; w->pat = 4; }
  if (kind == 0) { strcpy(w->title, "Untitled"); w->lines = 1; w->body[0][0] = 0; }
  else if (kind == 1) strcpy(w->title, "Macintosh HD");
  else if (kind == 3) strcpy(w->title, "MacPaint");
  else strcpy(w->title, "Trash");
  w->z = ++zseq;
  printf("MACGUI7: win kind=%d at %d,%d\n", kind, w->x, w->y);
}
static void focus_front(Win *w) { if (w) w->z = ++zseq; }
static void win_type(Win *w, char ch) {
  if (!w || w->kind != 0) return;
  if (w->lines == 0) { w->lines = 1; w->body[0][0] = 0; }
  int li = w->lines - 1, len = (int)strlen(w->body[li]);
  if (ch == 8) { if (len > 0) w->body[li][len - 1] = 0; else if (li > 0) w->lines--; w->caret = (int)strlen(w->body[w->lines - 1]); return; }
  if (ch == 10) { if (w->lines < 14) { w->lines++; w->body[w->lines - 1][0] = 0; } w->caret = 0; return; }
  if (len < 60) { w->body[li][len] = ch; w->body[li][len + 1] = 0; w->caret = len + 1; }
}
static void do_menu_item(int mi, int ii) {
  if (mi == 0 && ii == 0) { dlg = 1; printf("MACGUI7: about\n"); return; }
  if (mi == 1 && ii == 0) { open_win(0); return; }                 /* File > New */
  if (mi == 1 && ii == 3) { Win *t = top_win(); if (t) close_win(t); return; }  /* File > Close */
  if (mi == 1 && ii == 7) { dlg = 2; strcpy(dlg_msg, "It is now safe to turn off your Macintosh."); return; }
  if (mi == 4 && ii == 1) { dlg = 2; strcpy(dlg_msg, "The Trash is already empty."); return; }
  if (mi == 4 && ii == 3) { dlg = 2; strcpy(dlg_msg, "Shut Down is not available in this facsimile."); return; }
  if (mi == 0 && ii >= 2) { dlg = 2; snprintf(dlg_msg, sizeof dlg_msg, "%s is not available in this facsimile.", menus[mi].items[ii]); return; }
  if (mi == 2) { dlg = 2; strcpy(dlg_msg, "Nothing to undo."); return; }
}

static void button_down(void) {
  last_input_ms = now_ms();
  long ms = last_input_ms;
  printf("MACGUI7: click x=%d y=%d\n", px, py);
  /* dialog first (modal) */
  if (dlg) {
    int w = 380, h = (dlg == 1) ? 196 : 130;
    int x = (MACW - w) / 2, y = (MACH - h) / 2;
    int bx = x + w / 2 - 34, by = y + h - (dlg == 1 ? 34 : 40);
    if (px >= bx && px < bx + 68 && py >= by && py < by + 24) { dlg = 0; printf("MACGUI7: dlg ok\n"); }
    scene_dirty = 1;
    return;
  }
  /* open dropdown consumes clicks */
  if (menu_open >= 0) {
    int ii = dd_item_at(menu_open, px, py);
    if (ii >= 0) { int mi = menu_open; menu_open = -1; menu_sel = -1; do_menu_item(mi, ii); }
    else { int mi2 = menu_index_at(px, py); menu_open = (mi2 >= 0 && mi2 != menu_open) ? mi2 : -1; menu_sel = -1; }
    scene_dirty = 1;
    return;
  }
  int mi = menu_index_at(px, py);
  if (mi >= 0) { menu_open = mi; menu_sel = -1; scene_dirty = 1; return; }
  { int di = dock_hit(px, py); if (di >= 0) { dock_action(di); return; } }
  Win *w = hit_window(px, py);
  if (w) {
    focus_front(w);
    if (px >= w->x + 2 && px < w->x + 14 && py >= w->y + 2 && py < w->y + 14) { close_win(w); scene_dirty = 1; return; }
    if (py < w->y + TITLEBAR) { drag_w = w; drag_dx = px - w->x; drag_dy = py - w->y; scene_dirty = 1; return; }
    if (w->kind == 3) { mp_press(w, px, py); scene_dirty = 1; return; }
    scene_dirty = 1;
    return;
  }
  int i = hit_icon(px, py);
  if (i >= 0) {
    static long ic_ms = 0; static int ic_i = -1;
    if (ic_i == i && (ms - ic_ms) < 500) { open_win(icons[i].kind); printf("MACGUI7: OPEN icon=%d\n", i); if (icons[i].kind == 1) printf("MACGUI7: SOUND disk-insert\n"); ic_i = -1; }
    else { sel_icon = i; ic_i = i; ic_ms = ms; }
    scene_dirty = 1;
    return;
  }
  sel_icon = -1; scene_dirty = 1;
}

static char KMAP[256];
static void kmap_init(void) {
  memset(KMAP, 0, sizeof KMAP);
  KMAP[KEY_Q]='q'; KMAP[KEY_W]='w'; KMAP[KEY_E]='e'; KMAP[KEY_R]='r'; KMAP[KEY_T]='t';
  KMAP[KEY_Y]='y'; KMAP[KEY_U]='u'; KMAP[KEY_I]='i'; KMAP[KEY_O]='o'; KMAP[KEY_P]='p';
  KMAP[KEY_A]='a'; KMAP[KEY_S]='s'; KMAP[KEY_D]='d'; KMAP[KEY_F]='f'; KMAP[KEY_G]='g';
  KMAP[KEY_H]='h'; KMAP[KEY_J]='j'; KMAP[KEY_K]='k'; KMAP[KEY_L]='l';
  KMAP[KEY_Z]='z'; KMAP[KEY_X]='x'; KMAP[KEY_C]='c'; KMAP[KEY_V]='v'; KMAP[KEY_B]='b';
  KMAP[KEY_N]='n'; KMAP[KEY_M]='m';
  KMAP[KEY_1]='1'; KMAP[KEY_2]='2'; KMAP[KEY_3]='3'; KMAP[KEY_4]='4'; KMAP[KEY_5]='5';
  KMAP[KEY_6]='6'; KMAP[KEY_7]='7'; KMAP[KEY_8]='8'; KMAP[KEY_9]='9'; KMAP[KEY_0]='0';
  KMAP[KEY_SPACE]=' '; KMAP[KEY_DOT]='.'; KMAP[KEY_COMMA]=','; KMAP[KEY_MINUS]='-';
  KMAP[KEY_SLASH]='/'; KMAP[KEY_SEMICOLON]=';'; KMAP[KEY_EQUAL]='=';
}
static int shift_on = 0;
static void key_down(int code) {
  if (code == KEY_LEFTSHIFT || code == KEY_RIGHTSHIFT) { shift_on = 1; return; }
  if (code == KEY_ESC) { if (dlg) { dlg = 0; scene_dirty = 1; return; } if (menu_open >= 0) { menu_open = -1; scene_dirty = 1; return; } Win *t = top_win(); if (t) { close_win(t); scene_dirty = 1; } return; }
  if (dlg) return;
  if (code == KEY_ENTER || code == KEY_KPENTER) { win_type(top_win(), 10); scene_dirty = 1; return; }
  if (code == KEY_BACKSPACE) { win_type(top_win(), 8); scene_dirty = 1; return; }
  char c = KMAP[code & 0xff];
  if (c && shift_on && c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
  if (c) { win_type(top_win(), c); scene_dirty = 1; }
}
static void key_up(int code) { if (code == KEY_LEFTSHIFT || code == KEY_RIGHTSHIFT) shift_on = 0; }

static int tour_on, tour_i;
static void handle_event(int idx, struct input_event *e) {
  (void)idx;
  last_input_ms = now_ms();
  if (tour_on) { tour_on = 0; tour_i = 0; drag_w = NULL; }
  if (e->type == EV_REL) {
    if (e->code == REL_X) px += e->value;
    else if (e->code == REL_Y) py += e->value;
    if (px < 0) px = 0;
    if (px > MACW - 1) px = MACW - 1;
    if (py < 0) py = 0;
    if (py > MACH - 1) py = MACH - 1;
    if (drag_w) { drag_w->x = px - drag_dx; drag_w->y = py - drag_dy; scene_dirty = 1; }
    if (painting) { mp_drag(); scene_dirty = 1; }
    if (menu_open >= 0) { int ii = dd_item_at(menu_open, px, py); if (ii != menu_sel) { menu_sel = ii; scene_dirty = 1; } }
    return;
  }
  if (e->type == EV_KEY) {
    if (e->code == BTN_LEFT) { if (e->value == 1) button_down(); else if (e->value == 0) { drag_w = NULL; mp_release(); } return; }
    if (e->value == 1) key_down(e->code); else if (e->value == 0) key_up(e->code);
  }
}

/* ---- small-rect upkeep ---- */
static void caret_update(void) {
  Win *w = top_win();
  if (!w || w->kind != 0 || !have_fb || menu_open >= 0 || dlg) return;
  int li = w->lines ? w->lines - 1 : 0;
  char tmp[72]; int n = w->caret; if (n > 60) n = 60;
  memcpy(tmp, w->body[li], n); tmp[n] = 0;
  int bx = w->x + 1 + 6, by = w->y + TITLEBAR + 8 + li * (FONT_H + 2);
  int cx = bx + text_w(tmp), cy = by;
  unsigned int c = blink ? C_BLACK : C_WHITE;
  set_dst(scene); rect(cx, cy, 2, FONT_H, c);
  set_dst(front); rect(cx, cy, 2, FONT_H, c);
  blit_rect(cx, cy, 2, FONT_H);
}
static void clock_update(void) {
  static char last[16] = "";
  if (!have_fb || !scene) return;
  char clk[16]; clk_str(clk, 1);
  if (!strcmp(clk, last)) return;
  strcpy(last, clk);
  int w = text_w("00:00:00") + 2, x = MACW - 8 - text_w("00:00:00") - 1, y = 3;
  set_dst(scene); rect(x, y, w, FONT_H + 2, C_WHITE); text(x + 1, y + 1, clk, C_BLACK);
  set_dst(front); rect(x, y, w, FONT_H + 2, C_WHITE); text(x + 1, y + 1, clk, C_BLACK);
  blit_rect(x, y, w, FONT_H + 2);
}

static int prev_px = -1, prev_py = -1;
static void flush(void) {
  if (!have_fb || !scene || !front) return;
  if (scene_dirty) {
    set_dst(scene); redraw_scene();
    memcpy(front, scene, (size_t)mstride * MACH);
    blit_rect(0, 0, MACW, MACH);
    prev_px = -1; scene_dirty = 0;
  }
  if (prev_px >= 0) { restore_rect(prev_px - 1, prev_py - 1, 13, 18); blit_rect(prev_px - 1, prev_py - 1, 13, 18); }
  set_dst(front); draw_pointer(px, py);
  blit_rect(px, py, 11, 16);
  prev_px = px; prev_py = py;
}

/* ================= pointer tour (idle self-demo) ================= */
#define TOURN 14
typedef struct { int x, y, act; } TStep;   /* act: 0 move, 1 click, 2 dblclick, 3 press, 4 release, 5 wait(x=ticks) */
static TStep tour[TOURN];
static int tour_on = 0, tour_i = 0;
static void tour_init(void) {
  int i = 0;
  tour[i].x = icons[0].x + 16; tour[i].y = icons[0].y + 16; tour[i].act = 0; i++;
  tour[i].x = icons[0].x + 16; tour[i].y = icons[0].y + 16; tour[i].act = 2; i++;   /* open Macintosh HD */
  tour[i].x = 0;  tour[i].y = 0; tour[i].act = 5; tour[i].x = 20; i++;              /* settle */
  tour[i].x = 290; tour[i].y = 68; tour[i].act = 0; i++;
  tour[i].x = 290; tour[i].y = 68; tour[i].act = 3; i++;                            /* grab title bar */
  tour[i].x = 340; tour[i].y = 123; tour[i].act = 4; i++;                           /* drag */
  tour[i].x = 0; tour[i].y = 0; tour[i].act = 5; tour[i].x = 15; i++;
  tour[i].x = 198; tour[i].y = 123; tour[i].act = 1; i++;                           /* close box */
  tour[i].x = 0; tour[i].y = 0; tour[i].act = 5; tour[i].x = 15; i++;
  tour[i].x = 12; tour[i].y = 10; tour[i].act = 1; i++;                             /* Apple menu */
  tour[i].x = 60; tour[i].y = 31; tour[i].act = 1; i++;                             /* About item */
  tour[i].x = 0; tour[i].y = 0; tour[i].act = 5; tour[i].x = 30; i++;
  tour[i].x = 256; tour[i].y = 247; tour[i].act = 1; i++;                           /* OK */
  tour[i].x = 452; tour[i].y = 240; tour[i].act = 1;                                /* select Trash */
}
static void tour_tick(void) {
  if (!tour_on) { if (now_ms() - last_input_ms > 5000) { tour_on = 1; tour_i = 0; printf("MACGUI7: tour start\n"); } else return; }
  if (tour_i >= TOURN) tour_i = 0;
  TStep *t = &tour[tour_i];
  if (t->act == 5) { if (--t->x <= 0) { tour_i++; } return; }
  int dx = t->x - px, dy = t->y - py;
  int ad = (dx < 0 ? -dx : dx) + (dy < 0 ? -dy : dy);
  if (ad > 6) {
    int sx = dx / 4, sy = dy / 4;
    if (sx == 0 && dx != 0) sx = dx > 0 ? 1 : -1;
    if (sy == 0 && dy != 0) sy = dy > 0 ? 1 : -1;
    if (sx > 7) sx = 7; if (sx < -7) sx = -7;
    if (sy > 7) sy = 7; if (sy < -7) sy = -7;
    px += sx; py += sy;
    if (px < 0) px = 0; if (px > MACW - 1) px = MACW - 1;
    if (py < 0) py = 0; if (py > MACH - 1) py = MACH - 1;
    if (drag_w) { drag_w->x = px - drag_dx; drag_w->y = py - drag_dy; scene_dirty = 1; }
    return;
  }
  px = t->x; py = t->y;
  switch (t->act) {
    case 0: break;
    case 1: button_down(); drag_w = NULL; break;
    case 2: button_down(); drag_w = NULL; button_down(); drag_w = NULL; break;
    case 3: button_down(); break;
    case 4: drag_w = NULL; break;
  }
  tour_i++;
}

/* ================= boot ================= */
static void fb_init(void) {
  fb_fd = open("/dev/fb0", O_RDWR);
  if (fb_fd < 0) { printf("MACGUI7: no fb0 errno=%d\n", errno); return; }
  struct fb_var_screeninfo vi; struct fb_fix_screeninfo fi;
  if (ioctl(fb_fd, FBIOGET_VSCREENINFO, &vi) < 0 || ioctl(fb_fd, FBIOGET_FSCREENINFO, &fi) < 0) { puts("MACGUI7: fb ioctl fail"); return; }
  fb_w = vi.xres; fb_h = vi.yres; fb_bpp = vi.bits_per_pixel; fb_stride = fi.line_length;
  fb = mmap(NULL, (size_t)fb_stride * fb_h, PROT_READ | PROT_WRITE, MAP_SHARED, fb_fd, 0);
  if (fb == MAP_FAILED) { fb = NULL; puts("MACGUI7: fb mmap fail"); return; }
  size_t sz = (size_t)mstride * MACH;
  scene = malloc(sz); front = malloc(sz);
  if (!scene || !front) { puts("MACGUI7: alloc fail"); scene = front = NULL; return; }
  have_fb = 1;
  offx = (fb_w - MACW * SCALE) / 2; if (offx < 0) offx = 0;
  offy = (fb_h - MACH * SCALE) / 2; if (offy < 0) offy = 0;
  paint_letterbox();
  printf("MACGUI7: fb %dx%d bpp=%d | mac %dx%d x%d at +%d+%d\n", fb_w, fb_h, fb_bpp, MACW, MACH, SCALE, offx, offy);
}

int main(void) {
  setvbuf(stdout, NULL, _IONBF, 0);
  signal(SIGTTIN, SIG_IGN); signal(SIGTTOU, SIG_IGN); signal(SIGINT, SIG_IGN); signal(SIGTERM, SIG_IGN);
  mkdir("/dev", 0755);
  if (mount("devtmpfs", "/dev", "devtmpfs", 0, NULL) < 0) printf("MACGUI7: devtmpfs errno=%d\n", errno);
  else puts("MACGUI7: devtmpfs mounted");
  mkdir("/proc", 0755); mount("proc", "/proc", "proc", 0, NULL);
  kmap_init(); fb_init(); init_icons(); init_menus(); tour_init();
  for (int i = 0; i < NEV; i++) {
    char p[48]; snprintf(p, sizeof p, "/dev/input/event%d", i);
    ifd[i] = open(p, O_RDONLY | O_NONBLOCK);
    if (ifd[i] >= 0) { char nm[80] = {0}; ioctl(ifd[i], EVIOCGNAME(sizeof nm - 1), nm); printf("MACGUI7: input %s fd=%d name='%s'\n", p, ifd[i], nm); }
  }
  puts("MACGUI7: ready - Macintosh 128K facsimile (Apple 50th anniversary tribute)");
  last_input_ms = now_ms();
  int tick = 0;
  for (;;) {
    fd_set r; FD_ZERO(&r); int mx = -1;
    for (int i = 0; i < NEV; i++) if (ifd[i] >= 0) { FD_SET(ifd[i], &r); if (ifd[i] > mx) mx = ifd[i]; }
    struct timeval tv = {0, 33000};
    int n = select(mx + 1, &r, NULL, NULL, &tv);
    if (n > 0) for (int i = 0; i < NEV; i++) {
      if (ifd[i] < 0 || !FD_ISSET(ifd[i], &r)) continue;
      struct input_event ev;
      while (read(ifd[i], &ev, sizeof ev) == (ssize_t)sizeof ev) handle_event(i, &ev);
    }
    tour_tick();
    if (++tick % 16 == 0) { blink = !blink; caret_update(); }
    if (tick % 6 == 0) clock_update();
    flush();
  }
  return 0;
}

