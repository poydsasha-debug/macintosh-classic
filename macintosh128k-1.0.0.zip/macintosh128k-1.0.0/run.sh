#!/bin/bash
# run.sh - boot the Macintosh 128K facsimile in QEMU.
set -u
DIR=$(cd "$(dirname "$0")" && pwd)
KERNEL=${KERNEL:-"$DIR/zImage-dtb"}
INITRD=${INITRD:-"$DIR/initrd-macgui.img"}
[ -f "$KERNEL" ] || { echo "missing kernel: $KERNEL (set KERNEL=...)"; exit 1; }
[ -f "$INITRD" ] || { echo "missing initrd: $INITRD (run ./build.sh)"; exit 1; }
exec qemu-system-arm -M virt,highmem=off -cpu cortex-a7 -smp 1 -m 512 -name mac128k \
  -device virtio-gpu-pci,xres=1024,yres=768 \
  -device virtio-mouse-pci -device virtio-keyboard-pci \
  -display gtk \
  -monitor unix:/tmp/mac128k-monitor.sock,server=on,wait=off \
  -qmp unix:/tmp/mac128k-qmp.sock,server=on,wait=off \
  -chardev socket,id=ser0,path=/tmp/mac128k-serial.sock,server=on,wait=off,logfile=/tmp/mac128k-serial.log -serial chardev:ser0 \
  -kernel "$KERNEL" -initrd "$INITRD" \
  -append 'console=ttyAMA0,115200 video=1024x768 rw'

