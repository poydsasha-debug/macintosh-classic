# Macintosh 128K ファクシミリ

<img src="docs/images/hero.png" alt="Macintosh 128K ファクシミリ — Apple 50周年トリビュート" width="100%">

![platform](https://img.shields.io/badge/platform-OpenHarmony%20%2B%20QEMU-blue)
![arch](https://img.shields.io/badge/arch-ARM%20virt-lightgrey)
![display](https://img.shields.io/badge/%E5%86%85%E9%83%A8%E8%A7%A3%E5%83%8F%E5%BA%A6-512%C3%97342-success)
![license](https://img.shields.io/badge/license-MIT-green)

[English](README.md) · [简体中文](README.zh-CN.md) · **日本語** · [Español](README.es.md)

> **1984 年の Apple Macintosh 128K（System 1.0）**を忠実に再現したファクシミリ。
> **OpenHarmony + QEMU** 上で動作します。GUI 全体は静的 ARM バイナリ 1 個で、
> カーネルが小さな initrd から `/init` として起動します（OpenHarmony のユーザー空間は不要）。
>
> **Apple 50 周年（1976 – 2026）**に捧げます。

---

## ハイライト

| | |
|---|---|
| **実解像度 512×342** | 内部フレームバッファは Mac 128K の実解像度。×2 で 1024×684 に拡大し、周囲は黒帯（引き伸ばしではありません）。 |
| **レインボー Apple メニューバー** | 20px のメニューバーに 1977–1998 年版のレインボー Apple ロゴ、File / Edit / View / Special のプルダウンメニューが動作。 |
| **System 1.0 のウィンドウ** | 1px 黒枠、ストライプのタイトルバー、クローズボックス、右/下のスクロールバー（矢印付き）、サイズボックス、影。 |
| **MacPaint** | 5 つのツール（鉛筆 / 消しゴム / 直線 / 矩形 / スプレー）、8 パターン、260×140 キャンバス。ドラッグで描画。 |
| **Dock とタイリング** | 下部 Dock に Disk / Notes / Paint / Trash / **Tile**。Tile で全ウィンドウをグリッド整列。 |
| **秒針付き時計** | メニューバーに `HH:MM:SS`。時計部分だけを部分再描画するのでちらつきません。 |
| **アイドル時のポインタツアー** | 5 秒アイドルでポインタが自動デモ：ディスクを開く → ドラッグ → 閉じる → About → Trash 選択 → ループ。実入力で即座に中断。 |
| **フロッピー挿入音** | ゲストにサウンドカードが無いため、シリアルに合図を出力し、ホスト側の watcher が合成 WAV を再生します。 |
| **実機のマウス/キーボード** | virtio-input → `/dev/input/event*`。ポインタ追従、ダブルクリックで開く、タイトルバードラッグ、Esc で閉じる、文字入力可。 |

## スクリーンショット

| デスクトップ | ウィンドウ | About（50 周年） |
|---|---|---|
| ![desktop](docs/images/01-desktop.png) | ![window](docs/images/02-window.png) | ![about](docs/images/03-about.png) |

## デモ動画

- [`video/mac128k-demo.mp4`](video/mac128k-demo.mp4) — 1024×768、12.5 秒
- [`video/mac128k-demo.gif`](video/mac128k-demo.gif) — ループ GIF

## 実装のポイント

- **描画**：フレームバッファ（`/dev/fb0`、32bpp）に直接書き込み。ダブルバッファ＋小矩形の差分転送により、ポインタ移動で全画面再描画は発生しません。
- **入力**：libc 静的 ARM バイナリ（`arm-linux-gnueabi-gcc -static`）。`select()` と非ブロッキング `read()` で evdev を読みます。
  教訓：**入力イベントごとにシリアルへ printf してはいけません**（115200 baud ではメインループが詰まり画面がカクつきます）。
- **起動**：バイナリ自身が `/init`。カーネルには `CONFIG_INPUT_EVDEV` と fb サポートのみ必要。
- **フォント**：`tools/genfont.py` が DejaVuSans-Bold 11px から自動生成するプロポーショナルな Chicago 風ビットマップフォント。

## ビルド

```bash
# Linaro GCC 7.5 / arm-linux-gnueabi ツールチェーンが必要
CC=/path/to/arm-linux-gnueabi-gcc ./build.sh
```

`macgui-arm`（静的 ARM 実行ファイル）と `initrd-macgui.img`（`/init` がこのバイナリ）を生成します。

フォントの再生成（python3 + Pillow が必要）：

```bash
python3 tools/genfont.py        # src/font8x10.h を出力
```

## 実行

**QEMU ≥ 5.1**（arm `virt`）と ARM カーネル `zImage-dtb` が必要です。
参照環境は OpenHarmony 5.1 ソースツリーからビルドした `linux-5.10` カーネルを使用しています。

```bash
KERNEL=/path/to/zImage-dtb ./run.sh
```

## 操作

- QEMU ウィンドウを一度クリックしてフォーカスを与えてから、マウス/キーボードを使用します。
- アイコンを**ダブルクリック**で開く、タイトルバーを**ドラッグ**で移動、**クローズボックス**または **Esc** で閉じる。
- Dock：Disk / Notes / Paint / Trash / **Tile**。
- Apple メニュー → **About This Macintosh…** で周年ダイアログ。
- 5 秒アイドルでポインタツアーが始まります。

## ライセンス

MIT — [LICENSE](LICENSE) を参照。
Macintosh および Apple ロゴは Apple Inc. の商標です。本プロジェクトは**非営利のトリビュート**です。

