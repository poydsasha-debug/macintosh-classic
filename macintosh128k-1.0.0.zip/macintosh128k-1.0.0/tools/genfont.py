from PIL import Image, ImageDraw, ImageFont
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
SZ=11
f=ImageFont.truetype(FONT,SZ)
asc,desc=f.getmetrics()
H=asc+desc
wid=[]; maxw=0
for ch in range(32,127):
    b=f.getbbox(chr(ch))
    w=(b[2] if b else 0)
    wid.append(w); maxw=max(maxw,w)
W=maxw
lines=['/* auto-generated Chicago-ish PROPORTIONAL bitmap font (DejaVuSans-Bold %dpx), ASCII 32..126 */'%SZ,
       '#define FONT_W %d'%W,'#define FONT_H %d'%H,'#define FONT_FIRST 32',
       'static const unsigned char FONT8_W[95] = {'+','.join(str(w) for w in wid)+'};',
       'static const unsigned char FONT8[95][%d] = {'%H]
for ch in range(32,127):
    im=Image.new('1',(W,H),0); d=ImageDraw.Draw(im)
    d.text((0,asc),chr(ch),font=f,fill=1,anchor='ls')
    rows=[]
    for y in range(H):
        b=0
        for x in range(W):
            if im.getpixel((x,y)): b|=(1<<x)
        rows.append(b)
    lines.append('  {'+','.join('0x%02x'%b for b in rows)+'},')
lines.append('};')
open('/tmp/font8x10.h','w').write(chr(10).join(lines)+chr(10))
print('cell max',W,'x',H,'| widths A-Z:',wid[33:59])
