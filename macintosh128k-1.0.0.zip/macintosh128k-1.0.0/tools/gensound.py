
import numpy as np, wave, os, struct
SR=44100
def env(n,a,d): 
    t=np.arange(n)/SR
    e=np.exp(-t/d)
    e[:int(a*SR)] *= np.linspace(0,1,int(a*SR))
    return e
# classic floppy insert: motor spin-up + head-load clunk + soft whirr
dur=0.55; n=int(SR*dur); t=np.arange(n)/SR
# motor: 95Hz saw + 190Hz, amplitude rises then holds
saw=2*((t*95)%1)-1
motor=saw*0.22*np.minimum(1, t/0.06)
# head load clunk at 0.12s
clunk=np.zeros(n); c0=int(0.12*SR)
seg=env(int(0.10*SR),0.002,0.022)*np.random.uniform(-1,1,int(0.10*SR))
clunk[c0:c0+len(seg)]+=seg*0.55
# low thud
for f,a in ((58,0.5),(120,0.25)):
    tt=t-c0/SR; th=np.where(tt>=0, np.exp(-np.maximum(tt,0)/0.03)*np.sin(2*np.pi*f*np.maximum(tt,0)),0)
    clunk+=th*a*0.35
# whirr: filtered noise, slower decay
w=np.random.uniform(-1,1,n)
# simple one-pole lowpass
lp=np.zeros(n); a=0.06
for i in range(1,n): lp[i]=lp[i-1]+a*(w[i]-lp[i-1])
whirr=lp*0.5*env(n,0.01,0.30)
# final click of the disk seating
seat=np.zeros(n); s0=int(0.34*SR)
sg=env(int(0.05*SR),0.001,0.008)*np.random.uniform(-1,1,int(0.05*SR))
seat[s0:s0+len(sg)]+=sg*0.35
mix=motor+clunk+whirr+seat
mix=mix/np.max(np.abs(mix))*0.85
pcm=(mix*32767).astype('<i2')
out='/home/HUAWEI/.local/share/mac128k/disk-insert.wav'
os.makedirs(os.path.dirname(out), exist_ok=True)
w=wave.open(out,'wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes()); w.close()
print('wrote', out, os.path.getsize(out), 'bytes, peak', float(np.max(np.abs(mix))))

