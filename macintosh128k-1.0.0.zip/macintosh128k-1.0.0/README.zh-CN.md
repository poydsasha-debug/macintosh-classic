# Macintosh 128K 复刻

<img src="docs/images/hero.png" alt="Macintosh 128K 复刻 — 致敬苹果 50 周年" width="100%">

![platform](https://img.shields.io/badge/platform-OpenHarmony%20%2B%20QEMU-blue)
![arch](https://img.shields.io/badge/arch-ARM%20virt-lightgrey)
![display](https://img.shields.io/badge/%E5%86%85%E9%83%A8%E5%88%86%E8%BE%A8%E7%8E%87-512%C3%97342-success)
![license](https://img.shields.io/badge/license-MIT-green)

[English](README.md) · **简体中文** · [日本語](README.ja.md) · [Español](README.es.md)

> 一台**严格对标 1984 年 Apple Macintosh 128K（System 1.0）**的复刻，
> 跑在 **OpenHarmony + QEMU** 里。整个界面是一个静态 ARM 可执行文件，
> 由内核从极小的 initrd 里当作 `/init` 启动——不依赖任何 OpenHarmony 用户态。
>
> 谨以此**纪念苹果 50 周年（1976 – 2026）**。

---

## 亮点

| | |
|---|---|
| **真·512×342** | 内部帧缓冲就是 Mac 128K 的真实分辨率，×2 放大到 1024×684，四周黑边——不是拉伸。 |
| **彩虹苹果菜单栏** | 20px 菜单栏 + 1977–1998 版**彩虹 Apple 标志**，File / Edit / View / Special 可下拉且能执行。 |
| **System 1.0 窗口** | 1px 黑框、条纹标题栏、关闭框、左右滚动条（带箭头）、右下尺寸框、投影。 |
| **MacPaint 画板** | 5 种工具（铅笔/橡皮/直线/矩形/喷枪）、8 种图案、260×140 画布，拖动即画。 |
| **Dock + 平铺** | 底栏 Dock：Disk / Notes / Paint / Trash / **Tile**；点 Tile 把全部窗口网格平铺。 |
| **时钟走秒** | 菜单栏 `HH:MM:SS`，只重绘时钟那一小块，不闪屏。 |
| **空闲指针巡游** | 空闲 5 秒后指针自己巡游：开硬盘窗 → 拖窗 → 关窗 → 打开 About → 选中 Trash → 循环；真人一动手立刻接管。 |
| **软盘插入音效** | guest 无声卡：程序往串口打标记，宿主 watcher 用 paplay 播放合成的软驱插入声。 |
| **真键鼠** | virtio-mouse / virtio-keyboard → `/dev/input/event*`；指针跟手、双击开窗、拖拽、Esc 关窗、可打字。 |

## 截图

| 桌面 | 窗口 | About（50 周年） |
|---|---|---|
| ![desktop](docs/images/01-desktop.png) | ![window](docs/images/02-window.png) | ![about](docs/images/03-about.png) |

| 菜单 | 巡游 |
|---|---|
| ![menu](docs/images/04-menu.png) | ![tour](docs/images/03-tour.png) |

## 演示视频

- [`video/mac128k-demo.mp4`](video/mac128k-demo.mp4) — 1024×768，12.5 秒
- [`video/mac128k-demo.gif`](video/mac128k-demo.gif) — 循环 GIF

流程：干净桌面 → Dock 开硬盘窗 → **MacPaint 作画** → Notes 打字 → **多窗口平铺** → Apple 菜单 About。

## 实现要点

- **图形**：直接写 framebuffer（`/dev/fb0`，32bpp）。双缓冲（`scene` 内容层 / `front` 内容+指针层）+ 小矩形增量刷新，指针移动绝不整屏重绘。
- **输入**：libc 静态 ARM 二进制（`arm-linux-gnueabi-gcc -static`），`select()` + 非阻塞 `read()` 读 evdev。
  教训：**绝不要逐事件 printf 到串口 console**——115200 波特会把主循环阻塞到画面一顿一顿。
- **启动**：程序本身就是 `/init`，内核只需 `CONFIG_INPUT_EVDEV` 与 fb 支持。
- **字体**：Chicago 风格比例点阵，由 `tools/genfont.py` 从 DejaVuSans-Bold 11px 自动光栅化。

## 构建

```bash
# 需要 Linaro GCC 7.5 / arm-linux-gnueabi 工具链
CC=/path/to/arm-linux-gnueabi-gcc ./build.sh
```

产出 `macgui-arm`（静态 ARM 可执行）与 `initrd-macgui.img`（其中 `/init` 就是该二进制）。

重新生成字体（需要 python3 + Pillow）：

```bash
python3 tools/genfont.py        # 输出 src/font8x10.h
```

## 运行

需要 **QEMU ≥ 5.1**（arm `virt` 机型）+ 一个 ARM 内核 `zImage-dtb`。
参考环境使用自建 OpenHarmony 5.1 源码树编出的 `linux-5.10` 内核。

```bash
KERNEL=/path/to/zImage-dtb ./run.sh
```

## 操作

- 点一下 QEMU 窗口给它焦点，然后鼠标/键盘即可使用。
- **双击**桌面图标开窗；**拖动**标题栏移动窗口；点**关闭框**或按 **Esc** 关窗。
- Dock：Disk / Notes / Paint / Trash / **Tile**。
- Apple 菜单 → **About This Macintosh…** 看周年对话框。
- 空闲 5 秒，指针自己开始巡游。

## 验证记录

以下均在真实 QEMU guest 上抓帧 / 查串口日志验证：

| 项 | 证据 |
|---|---|
| 启动 | `fb 1024x768 bpp=32 | mac 512x342 x2 at +0+42` |
| 输入设备 | `event0 'QEMU Virtio Mouse'`、`event1 'QEMU Virtio Keyboard'` |
| 时钟走秒 | 相隔 1.6s 两帧，时钟区差异 60px |
| 指针精确 | 归零后 50 步 paced 移动，落点 `x=500 y=300` |
| 双击开窗 | `click x=956 y=248` → `win kind=1` → `OPEN icon=0` |
| MacPaint | 笔画落在画布上（652 黑像素，位置符合预期） |
| Dock | dock 区渲染（黑 2564 / 白 12636） |
| 音效 | `MACGUI7: SOUND disk-insert` 触发且宿主播放 |
| 巡游 | `tour start` → 开窗 → 拖窗 → 关窗 → `about` → `dlg ok` → 循环 |

## 许可

MIT —— 见 [LICENSE](LICENSE)。
Macintosh 与 Apple 标志为 Apple Inc. 的商标；本项目为**非商业致敬作品**。

