# Macintosh 128K Facsímil

<img src="docs/images/hero.png" alt="Macintosh 128K facsímil — homenaje al 50 aniversario de Apple" width="100%">

![platform](https://img.shields.io/badge/platform-OpenHarmony%20%2B%20QEMU-blue)
![arch](https://img.shields.io/badge/arch-ARM%20virt-lightgrey)
![display](https://img.shields.io/badge/resoluci%C3%B3n%20interna-512%C3%97342-success)
![license](https://img.shields.io/badge/license-MIT-green)

[English](README.md) · [简体中文](README.zh-CN.md) · [日本語](README.ja.md) · **Español**

> Un facsímil fiel del **Apple Macintosh 128K (System 1.0 / 1984)** que arranca dentro de
> **OpenHarmony sobre QEMU**. Toda la interfaz es un único binario ARM estático que el kernel
> ejecuta como `/init` desde un initrd mínimo — sin espacio de usuario de OpenHarmony.
>
> Dedicado al **50 aniversario de Apple (1976 – 2026)**.

---

## Lo más destacado

| | |
|---|---|
| **512×342 auténticos** | El framebuffer interno usa la resolución real del Mac 128K, escalada ×2 a 1024×684 con bandas negras — no estirada. |
| **Barra de menús con la manzana arcoíris** | Barra de 20px con el logotipo arcoíris de Apple (1977–1998) y menús desplegables funcionales: File / Edit / View / Special. |
| **Ventanas estilo System 1.0** | Marco negro de 1px, barra de título a rayas, caja de cierre, barras de desplazamiento derecha e inferior con flechas, caja de tamaño y sombra. |
| **MacPaint** | 5 herramientas (lápiz / borrador / línea / rectángulo / aerógrafo), 8 patrones, lienzo de 260×140; se dibuja arrastrando. |
| **Dock y mosaico** | Dock inferior con Disk / Notes / Paint / Trash / **Tile**; Tile ordena todas las ventanas en una cuadrícula. |
| **Reloj con segundos** | `HH:MM:SS` en la barra de menús, repintado solo en esa zona (sin parpadeo). |
| **Tour del puntero en reposo** | Tras 5 s de inactividad el puntero se mueve solo: abre el disco, lo arrastra, lo cierra, abre Acerca de, selecciona la Papelera y repite. Cualquier entrada real lo interrumpe. |
| **Sonido de disquete** | El invitado no tiene tarjeta de sonido: imprime una señal por el puerto serie y un vigilante en el anfitrión reproduce un WAV sintetizado. |
| **Ratón y teclado reales** | virtio-input → `/dev/input/event*`: el puntero sigue, doble clic abre, arrastrar la barra de título mueve, Esc cierra y se puede escribir. |

## Capturas

| Escritorio | Ventana | Acerca de (50 aniversario) |
|---|---|---|
| ![desktop](docs/images/01-desktop.png) | ![window](docs/images/02-window.png) | ![about](docs/images/03-about.png) |

## Vídeo de demostración

- [`video/mac128k-demo.mp4`](video/mac128k-demo.mp4) — 1024×768, 12,5 s
- [`video/mac128k-demo.gif`](video/mac128k-demo.gif) — GIF en bucle

## Cómo funciona

- **Gráficos**: escribe directamente en el framebuffer (`/dev/fb0`, 32 bpp). Doble búfer
  (`scene` = contenido, `front` = contenido + puntero) con copias incrementales de pequeños
  rectángulos, así mover el puntero nunca repinta la pantalla completa.
- **Entrada**: un binario ARM estático con libc (`arm-linux-gnueabi-gcc -static`) que hace
  `select()` sobre `/dev/input/event*` y lee en modo no bloqueante.
  Lección aprendida: **nunca imprimir por evento en la consola serie** — a 115200 baudios
  bloquea el bucle principal y la pantalla se entrecorta.
- **Arranque**: el binario *es* `/init`; el kernel solo necesita `CONFIG_INPUT_EVDEV` y fb.
- **Tipografía**: fuente de mapa de bits proporcional estilo Chicago, generada por
  `tools/genfont.py` a partir de DejaVuSans-Bold 11 px.

## Compilar

```bash
# requiere un toolchain Linaro GCC 7.5 / arm-linux-gnueabi
CC=/path/to/arm-linux-gnueabi-gcc ./build.sh
```

Genera `macgui-arm` (ejecutable ARM estático) y `initrd-macgui.img` (cuyo `/init` es el binario).

Regenerar la fuente (requiere python3 + Pillow):

```bash
python3 tools/genfont.py        # escribe src/font8x10.h
```

## Ejecutar

Requiere **QEMU ≥ 5.1** (máquina arm `virt`) y un kernel ARM `zImage-dtb`.
El entorno de referencia usa un kernel `linux-5.10` compilado desde un árbol de OpenHarmony 5.1.

```bash
KERNEL=/path/to/zImage-dtb ./run.sh
```

## Controles

- Haz clic una vez en la ventana de QEMU para darle el foco y usa el ratón/teclado.
- **Doble clic** en un icono para abrirlo; **arrastra** la barra de título para mover la ventana;
  pulsa la **caja de cierre** o **Esc** para cerrarla.
- Dock: Disk / Notes / Paint / Trash / **Tile**.
- Menú Apple → **About This Macintosh…** para el diálogo del aniversario.
- Déjalo inactivo 5 s y el puntero iniciará su tour.

## Licencia

MIT — véase [LICENSE](LICENSE).
Macintosh y el logotipo de Apple son marcas de Apple Inc. Este es un **homenaje no comercial**.

