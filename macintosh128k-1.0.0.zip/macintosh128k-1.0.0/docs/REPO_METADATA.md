# 仓库元信息 / Repository metadata

> 用于 GitHub 仓库的 **Description**、**Topics**、**Social preview** 与系列命名。
> 以下内容可直接复制粘贴到网页设置里。

## 系列定位 / Series

**系列名：致敬苹果系列（Tribute to Apple series）**

本仓库是该系列的 **第 1 部**：

| 序号 | 仓库 | 主题 | 状态 |
|---|---|---|---|
| 01 | `macintosh128k` | 1984 Macintosh 128K / System 1.0 | ✅ 本仓库 |
| 02 | *(待定)* | 待续 | — |

---

## 仓库描述 / Description（GitHub Description 栏，≤350 字符）

### 推荐（中英双语，约 200 字符）
```
致敬苹果 50 周年系列 01 · 严格复刻 1984 年 Macintosh 128K（System 1.0），跑在 OpenHarmony + QEMU 上。512×342 真分辨率×2、彩虹苹果菜单栏、MacPaint 画板、Dock 多窗口平铺、空闲指针巡游。 | Tribute to Apple's 50th anniversary: a faithful Macintosh 128K facsimile on OpenHarmony + QEMU.
```

### 纯中文（更短）
```
致敬苹果系列 01 —— 复刻 1984 年 Macintosh 128K：512×342 真分辨率、彩虹苹果菜单栏、MacPaint、Dock 平铺、指针巡游自动演示。跑在 OpenHarmony + QEMU 上。
```

### 纯英文
```
Tribute to Apple series #01 — a faithful Apple Macintosh 128K (System 1.0, 1984) facsimile running on OpenHarmony + QEMU. Authentic 512x342 screen, rainbow Apple menu bar, MacPaint, Dock tiling, idle pointer tour.
```

---

## 话题标签 / Topics（最多 20 个，小写 + 连字符）

```
apple-tribute
apple-50th-anniversary
macintosh
macintosh-128k
system-1
retro-computing
vintage-apple
openharmony
qemu
arm
bare-metal
framebuffer
evdev
gui
macpaint
emulator
c
retro
facsimile
1984
```

> 建议保留前 15 个，后面的 `facsimile` / `1984` 可让位给未来系列新仓库的标签。

---

## 社交预览图 / Social preview

在 **Settings → Social preview → Upload an image** 上传：

```
docs/images/hero.png      (1280×420)
```

---

## 关于 / About（可放 README 顶部或 Release 正文）

**中文**

> **致敬苹果系列 01 —— Macintosh 128K**
> 1984 年，Apple 用一台 512×342 像素、没有硬盘、只有 128KB 内存的小盒子，
> 定义了"图形界面"该有的样子。42 年后，我们用 OpenHarmony 与 QEMU
> 把它一像素一像素地重画了一遍：彩虹苹果菜单栏、条纹标题栏、滚动条、尺寸框、
> MacPaint、甚至软驱插入的咔哒声。
> 谨以此纪念苹果 50 周年 —— 1976 – 2026。

**English**

> **Tribute to Apple series #01 — Macintosh 128K**
> In 1984, a 512x342-pixel box with no hard disk and 128 KB of RAM defined what a
> graphical interface should feel like. 42 years later we redrew it pixel by pixel on
> OpenHarmony + QEMU: rainbow Apple menu bar, striped title bars, scroll bars, size box,
> MacPaint, and even the clunk of a floppy going in.
> Dedicated to Apple's 50th anniversary — 1976 – 2026.

---

## 仓库命名建议 / Naming

- 本仓库：`macintosh128k`（当前）
- 若想突出系列：`apple-tribute-01-macintosh-128k`
- 系列用统一前缀 `apple-tribute-XX-…` 便于聚合

