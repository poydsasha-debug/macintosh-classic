# Macintosh 128K Facsimile — v1.0.0

<img src="../docs/images/hero.png" alt="Macintosh 128K facsimile" width="100%">

**🎉 Tribute to Apple's 50th Anniversary (1976 – 2026)**

A faithful **Apple Macintosh 128K (System 1.0, 1984)** facsimile that boots inside
**OpenHarmony on QEMU**. The entire GUI is one static ARM binary run by the kernel as
`/init` — no OpenHarmony userspace required.

## What's in this release

- **Authentic 512×342** internal framebuffer (the real Mac 128K resolution), scaled ×2 to
  1024×684 with black letterboxing.
- **Rainbow Apple menu bar** (1977–1998 logo) with working pull-down menus:
  File / Edit / View / Special.
- **System 1.0 window chrome**: striped title bar, close box, right + bottom scroll bars with
  arrows, size box, drop shadow.
- **MacPaint**: 5 tools, 8 patterns, 260×140 canvas, drag to draw.
- **Dock + multi-window tiling** (Disk / Notes / Paint / Trash / Tile).
- **Menu-bar clock with seconds**, repainted as a small rect (flicker-free).
- **Idle pointer tour**: a self-running demo that yields instantly to real input.
- **Floppy-insert sound**: serial cue from the guest, synthesized WAV on the host.
- **Real mouse & keyboard** through virtio-input and `/dev/input/event*`.
- **Double-buffered renderer** with incremental small-rect blits.

## Assets

| File | Description |
|---|---|
| `macgui-arm` | static ARM executable (the whole GUI) |
| `initrd-macgui.img` | initrd whose `/init` is the GUI binary |
| `video/mac128k-demo.mp4` | 1024×768 demo, 12.5 s |
| `video/mac128k-demo.gif` | looping GIF |
| `docs/images/*.png` | screenshots + hero banner |

> `zImage-dtb` is **not** bundled: build or obtain an ARM `virt` kernel
> (a `linux-5.10` kernel from an OpenHarmony 5.1 tree works) and point `KERNEL=` at it.

## Quick start

```bash
CC=/path/to/arm-linux-gnueabi-gcc ./build.sh
KERNEL=/path/to/zImage-dtb ./run.sh
```

## Documentation

- [English](../README.md) · [简体中文](../README.zh-CN.md) · [日本語](../README.ja.md) · [Español](../README.es.md)

## License

MIT. Macintosh and the Apple logo are trademarks of Apple Inc.
This is a non-commercial tribute.

