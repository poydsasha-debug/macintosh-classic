# Changelog

## 1.0.0 — 2026-10-03

First public release. Apple 50th anniversary tribute.

### Added
- Authentic Macintosh 128K facsimile: internal 512x342, scaled x2 to 1024x684.
- Menu bar with the rainbow Apple logo and working pulldown menus (File / Edit / View / Special).
- System 1.0 window chrome: striped title bar, close box, right + bottom scroll bars, size box.
- MacPaint: 5 tools, 8 patterns, 260x140 canvas.
- Dock with Disk / Notes / Paint / Trash and a Tile action for multi-window tiling.
- Menu-bar clock with seconds (small-rect repaint).
- Idle pointer tour (self-running demo) that yields to any real input.
- Real mouse/keyboard input via virtio-input and /dev/input/event*.
- Floppy-insert sound: guest serial cue mirrored to the host speakers.
- Double-buffered renderer with incremental blits (flicker-free pointer).
- Demo video and multilingual documentation (EN / zh-CN / ja / es).

