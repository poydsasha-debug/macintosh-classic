#!/bin/bash
# build.sh - cross-compile the Macintosh 128K facsimile and pack the initrd.
set -e
DIR=$(cd "$(dirname "$0")" && pwd)
CC=${CC:-arm-linux-gnueabi-gcc}
SRC="$DIR/src/macgui6.c"
OUT="$DIR/macgui-arm"

echo "CC = $CC"
"$CC" -static -O2 -I "$DIR/src" -o "$OUT" "$SRC"
echo "built $OUT ($(stat -c%s "$OUT") bytes)"

rm -rf "$DIR/build"; mkdir -p "$DIR/build"
cp "$OUT" "$DIR/build/init"; chmod 755 "$DIR/build/init"
( cd "$DIR/build" && find . | cpio -o -H newc --quiet | gzip -9 > "$DIR/initrd-macgui.img" )
echo "built $DIR/initrd-macgui.img ($(stat -c%s "$DIR/initrd-macgui.img") bytes)"

